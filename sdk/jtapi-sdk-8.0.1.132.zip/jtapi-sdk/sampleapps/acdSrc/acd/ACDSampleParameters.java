package acd;

/**
 * 
 */

/**
 * @author sswamy
 *
 */
public enum ACDSampleParameters {
	JTAPICLASSNAME,
	SERVICENAME,
	LOGIN,
	PASSWORD,
	ACD,
	AGENT1,
	AGENT2,
	STATION1,
	STATION2;
}
